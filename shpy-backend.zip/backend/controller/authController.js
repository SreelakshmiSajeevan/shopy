const { hashPassword, comparePassword } = require('../helpers/authHelper')
const userModel = require('../models/userModel')
const orderModel = require('../models/orderModel')
const jwt = require('jsonwebtoken')
const fs = require('fs')



exports.registerController = async(req,res) =>{
    try{
       const {name,email,password,phone,address} = req.body
    //    validators
    if(!name && !email && !password && !phone && !address){
        return res.send({error:'Please enter all fields!'})
    } 
    // check user
    const existingUser = await userModel.findOne({email})
    if(existingUser){
        return res.status(200).send({
            success:true,
            message: 'Already registered please login'

        })
    }else{
            // register user
    const hashedPassword = await hashPassword(password)
    // save
    const user =  new userModel({name,email,password:hashedPassword,phone,address})
    await user.save()
    res.status(201).send({
        success:true,
        message:"User register successfully",
        user
    })
    }

    }catch(err){
        console.log(err);
        res.status(500).send({
            success: false,
            message: 'Error in Registration',err
        })
    }
}

// login post
exports.loginController = async(req,res)=>{
    try{
        const {email, password} = req.body
        if(!email || !password){
            return res.status(404).send({
                success: false,
                message: 'Please fill the form completely'
            })
        }
        const user = await userModel.findOne({email})
        if(!user){
            return res.status(404).send({
                success: false,
                message:'Email is not registerd'
            })
        }
        const match = await comparePassword(password,user.password)
        if(!match){
            return res.status(404).send({
                success: false,
                message: "incorrect password"
            })
        }
        // token
        const token = await jwt.sign({_id: user._id},process.env.JWT_SECRET,{
            expiresIn: "7d"
        })
        res.status(200).send({
            success:true,
            message:"Login succesful",
            user:{
                id: user._id,
                name: user.name,
                email:user.email,
                phone:user.phone,
                address: user.address,
                role: user.role
            },
            token
        })
    }catch(err){
        console.log(err);
        res.status(500).send({
            success: false,
            message:'Error in login',
            err
        })

    }
}

// test controller
exports.testcontroller = async(req,res)=>{
    res.send('Protected Routes')
}

// get users
exports.getUsersController = async(req,res)=>{
    try{
    const users = await userModel.find({ "name": { "$ne": "Admin" } })
    res.status(200).send({
        success: true,
        message:'Users details fetched successfully!',
        users
    })
   }catch(err){
    res.status(500).send({
        success:false,
        message:'Error occured',
        err
    })
   }
}


  //upate profile
  exports.updateUserController = async (req, res) => {
    try {
      const { name, phone, address } = req.fields;
      const { photo } = req.files;
      //alidation
      switch (true) {
        case !name:
          return res.status(500).send({ error: "Name is Required" });
        case !phone:
          return res.status(500).send({ error: "Phone is Required" });
        case !address:
          return res.status(500).send({ error: "Address is Required" });
        case photo && photo.size > 1000000:
          return res
            .status(500)
            .send({ error: "photo is Required and should be less then 1mb" });
      }
  
      const user = await userModel.findByIdAndUpdate(
        req.params.id,
        { ...req.fields},
        { new: true }
      );
      if (photo) {
        user.photo.data = fs.readFileSync(photo.path);
        user.photo.contentType = photo.type;
      }
      await user.save();
      res.status(201).send({
        success: true,
        message: "Profile Updated Successfully",
        user,
      });
    } catch (error) {
      console.log(error);
      res.status(500).send({
        success: false,
        error,
        message: "Error in Update profile",
      });
    }
  };

  // get a user
  exports.getUserDetailsController = async(req, res)=>{
    try{
      const id = req.params.id
      const user = await userModel.findById(id)
      res.status(200).send({
          success: true,
          message:'Users details fetched successfully!',
          user
      })
     }catch(err){
      console.log(err);
      res.status(500).send({
          success:false,
          message:'Error occured',
          err
      })
     }
  }

    // get photo
exports.userPhotoController = async (req, res) => {
  try {
    const user = await userModel.findById(req.params.pid).select("photo");
    if (user.photo.data) {
      res.set("Content-type", user.photo.contentType);
      return res.status(200).send(user.photo.data);
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Erorr while getting photo",
      error,
    });
  }};

  

// get orders
exports.getUserOrders = async(req,res)=>{
  try{
    const id = req.params.id
    const orders = await orderModel.find({buyer: id }).populate("products", "-photo").populate("buyer", "name");
    if(orders){
      res.status(200).json({
        success: true,
        message:'Ordered Items are fetched successfully',
        orders
      })
    }else{
      res.status(404).res.send("No orders")
    }
  }catch(err){
    console.log(err);
    res.status(500).send({
      success:false,
      message:'Error in getting orders',
      err
    })
  }
}

// get all orders
exports.getAllOrders = async(req,res)=>{
  try{
    const orders = await orderModel.find().populate("products", "-photo").populate("buyer", "name");
    res.status(200).send({
      success: true,
      message:'Orders are fetched successfully!',
      orders
    })
  }catch(err){
    console.log(err);
    res.status(500).send({
      success:false,
      message:'Error in fetching orders',
      err
    })
  }
}


// update order status
exports.orderStatusController = async (req, res) => {
  try {
    const  orderId  = req.params.id;
    const {status}   = req.body
    console.log(status);
    const orders = await orderModel.findByIdAndUpdate(
      orderId,
       {status} ,
      { new: true }
    );
    res.status(200).json(orders);
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error While Updating Order",
      error,
    });
  }
};